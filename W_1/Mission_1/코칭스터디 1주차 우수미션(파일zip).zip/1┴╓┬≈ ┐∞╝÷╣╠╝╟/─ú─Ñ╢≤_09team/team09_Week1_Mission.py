#Q1
num_list = [1, 5, 7, 15, 16, 22, 28, 29]

def get_odd_num(num_list):
    return [num for num in num_list if num %2 == 1]

print(get_odd_num(num_list))

#Q2
sentence = "way a is there will a is there where"

def reverse_sentence(sentence):
    #TO DO
    word_list = sentence.split()
    word_list.reverse()
    return " ".join(word_list)

print(reverse_sentence(sentence))

#Q3
score = [(100,100), (95,90), (55,60), (75,80), (70,70)]

def get_avg(score):
    for i in range(len(score)):
        score1,score2 = score[i]
        print(f"{i+1} 번, 평균:{sum([score1,score2])/2}")
        
get_avg(score)

#Q4
dict_first = {'사과': 30, '배':15,'감':10,'포도':10}
dict_second = {'사과':5, '감':25, '배':15, '귤':25}

def merge_dict(dict_first, dict_second):
    #TO DO
    result = {**dict_first, **dict_second}
    
    for key_first in dict_first.keys():
        if key_first in dict_second.keys():
            result[key_first] = dict_first[key_first] + dict_second[key_first]
            
    return result

merge_dict(dict_first, dict_second)

#Q5
import re

inputs = "cat32dog16cow5"
def find_string(inputs):
    return[i for i in re.split('[0-9]',inputs) if i!=""]

string_list = find_string(inputs)
print(string_list)