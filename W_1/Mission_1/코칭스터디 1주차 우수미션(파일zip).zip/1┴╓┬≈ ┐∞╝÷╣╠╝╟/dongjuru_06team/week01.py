# Q1
num_list = [1, 5, 7, 15, 16, 22, 28, 29]

def get_odd_num(num_list):
    """
    Q1. num_list에서 홀수인 데이터만 반환
    """
    odd_num_list = [num for num in num_list if num % 2 == 1]
    return odd_num_list
print(get_odd_num(num_list))

# Q2
sentence = "way a is there will a is there where"

def reverse_sentence(sentence):
    """
    Q2. 입력받은 string 역순으로 반환
    """
    return ' '.join(reversed(sentence.split()))

print(reverse_sentence(sentence))

# Q3
score = [(100, 100), (95, 90), (55, 60), (75, 80), (70, 70)]

def get_avg(score):
    """
    Q3. 각 학생별 평균 점수 출력
    """
    for i, s in enumerate(score):
        print(f"{i+1} 번, 평균 : {sum(s)/len(s)}")

get_avg(score)

# Q4
dict_first = {'사과': 30, '배': 15, '감': 10, '포도': 10}
dict_second = {'사과': 5, '감': 25, '배': 15, '귤': 25}

def merge_dict(dict_first, dict_second):
    """
    Q4. 딕셔너리 객체의 key값에 따라 value를 더하여 반환
    """
    result = dict_first
    for k, v in dict_second.items():
        if k in result:
            result[k] += v
        else:
            result[k] = v
    return result

print(merge_dict(dict_first, dict_second))

# Q5
import re

inputs = "cat32dog16cow5"

def find_string(inputs):
    """
    string의 숫자를 기준으로 분할하여 반환
    """
    lst = re.findall(r'\D+', inputs)
    return lst

string_list = find_string(inputs)
print(string_list)
